import React, { createContext, useState } from "react";

export const AppContext = createContext();

export const AppContextProvider = ({ children }) => {
	const [logged, setLogged] = useState(false);
	const [slider, setSlider] = useState(true);
	const [sliderImg, setSliderImg] = useState({});
	const [boxColor, setBoxColor] = useState({
		1: "#000000",
		2: "#000000",
		3: "#000000",
	});
	const [courseOrder, setCourseOrder] = useState({ 1: "1", 2: "2", 3: "3" });
	const [footerText, setFooterText] = useState({
		1: "Powered by ",
		2: "dewjpl",
	});

	const contextValue = {
		logged,
		setLogged,
		slider,
		setSlider,
		sliderImg,
		setSliderImg,
		boxColor,
		setBoxColor,
		courseOrder,
		setCourseOrder,
		footerText,
		setFooterText,
	};

	return (
		<AppContext.Provider value={contextValue}>{children}</AppContext.Provider>
	);
};
