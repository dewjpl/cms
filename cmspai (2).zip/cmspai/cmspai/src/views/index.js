import Home from './home/Home';
import Admin from './admin/Admin';
export { Home, Admin };