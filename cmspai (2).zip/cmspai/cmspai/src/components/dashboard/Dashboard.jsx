import "./Dashboard.scss";
import { useContext } from "react";
import { AppContext } from "./../../context/app.context";
import { Link } from "react-router-dom";
import React from "react";

const Dashboard = () => {
	const logout = () => {
		setLogged(false);
	};

	const {
		logged,
		setLogged,
		slider,
		setSlider,
		sliderImg,
		setSliderImg,
		boxColor,
		setBoxColor,
		courseOrder,
		setCourseOrder,
		footerText,
		setFooterText,
	} = useContext(AppContext);

	const handleInputChange = (e, setState) => {
		const index = Number(e.target.name);
		const value =
			e.target.type === "number" ? Number(e.target.value) : e.target.value;

		setState((prevState) => ({
			...prevState,
			[index]: value,
		}));
	};

	return (
		<div className="dash">
			<div className="hm-btn">
				<Link to="/">Show home page</Link>
			</div>
			<div className="s-stngs">
				<div className="tlt">
					<h2>Slider</h2>
					<button onClick={() => setSlider(!slider)}>
						{slider ? "OFF" : "ON"}
					</button>
				</div>
				<div className="img-sldr">
					<h2>Sliders IMG</h2>
					<div className="sldr">
						{[1, 2, 3].map((index) => (
							<input
								key={index}
								onChange={(e) => handleInputChange(e, setSliderImg)}
								defaultValue={sliderImg[index]}
								type="text"
								name={index}
							/>
						))}
					</div>
					<div className="bx-clr">
						<h2>Box colors</h2>
						<div className="inpt-in-clr">
							{[1, 2, 3].map((index) => (
								<input
									key={index}
									onChange={(e) => handleInputChange(e, setBoxColor)}
									defaultValue={boxColor[index]}
									type="color"
									name={index}
								/>
							))}
						</div>
					</div>
					<div className="crs-ordr">
						<h2>Courses Order</h2>
						<div className="inpt-in-crs">
							{[1, 2, 3].map((index) => (
								<input
									key={index}
									onChange={(e) => handleInputChange(e, setCourseOrder)}
									defaultValue={courseOrder[index]}
									type="number"
									min={1}
									max={3}
									name={index}
								/>
							))}
						</div>
					</div>
					<div className="text-ftr">
						<h2>Footer text</h2>
						<div className="inpt-in-ftr">
							{[1, 2].map((index) => (
								<input
									key={index}
									onChange={(e) => handleInputChange(e, setFooterText)}
									defaultValue={footerText[index]}
									type="text"
									name={index}
								/>
							))}
						</div>
					</div>
				</div>
				<li>
					{logged && (
						<a href="./" className="lgt" onClick={logout}>
							Wyloguj
						</a>
					)}
				</li>
			</div>
		</div>
	);
};

export default Dashboard;
