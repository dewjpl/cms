import React from "react";
import "./Slider.scss";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from "react-responsive-carousel";
import { useContext } from "react";
import { AppContext } from "../../context/app.context";

const Slider = () => {
	const { sliderImg } = useContext(AppContext);
	return (
		<div className="slider container">
			<Carousel>
				<div className="sld slide-1">
					<img src={sliderImg[1]} alt="" />
					<p className="legend">Slide 1</p>
				</div>
				<div className="sld slide-2">
					<img src={sliderImg[2]} alt="" />
					<p className="legend">Slide 2</p>
				</div>
				<div className="sld slide-3">
					<img src={sliderImg[3]} alt="" />
					<p className="legend">Slide 3</p>
				</div>
			</Carousel>
		</div>
	);
};

export default Slider;
