import { AppContext } from "../../context/app.context";
import "./Courses.scss";
import { useContext } from "react";

const Courses = () => {
	const { courseOrder } = useContext(AppContext);
	return (
		<div id="crss" className="ctn">
			<div className="crss">
				<div className="crs" style={{ order: courseOrder[1] }}>
					<h2>Bugatti Chiron</h2>
					<p>
						Bugatti Chiron to kwintesencja luksusu i oszałamiającej mocy.
						Napędzany potężnym 8.0-litrowym, 16-cylindrowym silnikiem o
						podwójnym doładowaniu, ten hipersamochód potrafi rozpędzić się od 0
						do 100 km/h w zaledwie około 2,5 sekundy. Z zewnętrznymi kształtami
						przypominającymi rzeźbę, Chiron jest symbolem doskonałości w świecie
						samochodów superszybkich.
					</p>
				</div>
				<div className="crs" style={{ order: courseOrder[2] }}>
					<h2>Koenigsegg Jesko</h2>
					<p>
						Koenigsegg Jesko to hipersamochód, który zrewolucjonizował świat
						prędkości. Wyposażony w potężny 5.0-litrowy silnik V8 z podwójnym
						doładowaniem, Jesko generuje ponad 1600 koni mechanicznych. Jego
						aerodynamiczne kształty zapewniają doskonałą przyczepność,
						umożliwiając kierowcy osiągnięcie niewiarygodnych prędkości bez
						utraty kontroli nad pojazdem.
					</p>
				</div>
				<div className="crs" style={{ order: courseOrder[3] }}>
					<h2>Ferrari LaFerrari</h2>
					<p>
						LaFerrari jest połączeniem doskonałego designu, wydajności i
						technologii. Ten hipersamochód jest napędzany przez 6.3-litrowy
						silnik V12, który współpracuje z systemem KERS, przekształcając
						energię kinetyczną w dodatkową moc. Z wyjątkowymi osiągami i
						eleganckim wyglądem, LaFerrari to marzenie każdego miłośnika
						szybkich samochodów.
					</p>
				</div>
			</div>
		</div>
	);
};

export default Courses;
