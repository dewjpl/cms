import React, { useContext } from "react";
import "./Boxes.scss";
import { AppContext } from "../../context/app.context";

const categories = [
	{
		title: "Sedany",
		vehicles: [
			"Honda Accord",
			"Toyota Camry",
			"Ford Fusion",
			"BMW 3 Series",
			"Mercedes-Benz E-Class",
		],
	},
	{
		title: "Hatchbacki",
		vehicles: [
			"Volkswagen Golf",
			"Ford Focus",
			"Honda Civic Hatchback",
			"Mazda3",
			"Toyota Prius",
		],
	},
	{
		title: "SUV-y",
		vehicles: [
			"Jeep Grand Cherokee",
			"Ford Explorer",
			"Toyota RAV4",
			"Nissan Rogue",
			"Honda CR-V",
		],
	},
];

const Boxes = () => {
	const { boxColor } = useContext(AppContext);

	return (
		<div id="boxes" className="container">
			<div className="boxes">
				{categories.map((category, index) => (
					<div
						key={index}
						className="bx-txt"
						style={{ backgroundColor: boxColor[index + 1] }}
					>
						<h2>{category.title}</h2>
						<ul>
							{category.vehicles.map((vehicle, idx) => (
								<li key={idx}>{vehicle}</li>
							))}
						</ul>
					</div>
				))}
			</div>
		</div>
	);
};

export default Boxes;
